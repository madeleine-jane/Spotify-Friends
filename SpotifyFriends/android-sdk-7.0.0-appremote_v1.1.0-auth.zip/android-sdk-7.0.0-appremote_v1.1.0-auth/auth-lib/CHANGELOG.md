Change Log
==========

## Version 1.1.0

_2018-02-28_

* Upgrade target and compile SDKs to 27
* Upgrade android support libraries to 27.0.2
